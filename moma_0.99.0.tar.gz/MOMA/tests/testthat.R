library(testthat)
library(moma)

test_check("moma")
