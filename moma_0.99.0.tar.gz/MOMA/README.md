# MOMA

This package is used for running Multi-Omic Master Regulator Analysis (MOMA).
See vignette for full steps to running the analysis.

