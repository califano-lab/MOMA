## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(MOMA)

## ----explore data-------------------------------------------------------------
library(moma.gbmexample)
names(gbm.example)
dim(gbm.example$vipermat)
gbm.example$vipermat[1:3, 1:3]

## ----pathways-----------------------------------------------------------------
pathways <- list()
pathways[['cindy']] = gbm.example$cindy
pathways[['preppi']] = gbm.example$preppi

## ----moma object--------------------------------------------------------------
momaObj <- moma_constructor(gbm.example$vipermat, gbm.example$rawsnp,
        gbm.example$rawcnv, gbm.example$fusions, pathways,
        gene.blacklist=gbm.example$mutSig)

## ----interactions, results = "hide", message = FALSE--------------------------
momaObj$runDIGGIT(fCNV=gbm.example$fCNV, verbose = TRUE)

momaObj$makeInteractions()

momaObj$Rank()

## ----clustering---------------------------------------------------------------
momaObj$Cluster()

# get the reliability scores. The 4th value is the highest and this corresponds
# with the 5 cluster solution
sapply(momaObj$clustering.results, "[[", "reliability")

# pick the 5 cluster solution and save it to the moma Object
momaObj$sample.clustering <- momaObj$clustering.results[[4]]$clustering

## ----saturation, message=FALSE, results="hide"--------------------------------
momaObj$saturationCalculation()

## ----checkpoints--------------------------------------------------------------
cluster1.checkpoint <- momaObj$checkpoints[[1]]
print (cluster1.checkpoint[1:10])

## ----make plots, warning=FALSE, include=FALSE---------------------------------
plots <- makeSaturationPlots(momaObj, fCNV = gbm.example$fCNV)

## ----visualize plots----------------------------------------------------------
library(ggplot2)
library(grid)
grid.draw(plots$oncoprint.plots[[3]])
plots$curve.plots[[3]] +
  ggtitle("Genomic Saturation Curve for GBM Subtype 3")
  

