## ---- include = FALSE----------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup---------------------------------------------------------------
library(moma)

## ----explore data--------------------------------------------------------
names(gbm.example)
dim(gbm.example$vipermat)
gbm.example$vipermat[1:3, 1:3]

## ----pathways------------------------------------------------------------
pathways <- list()
pathways[['cindy']] = gbm.example$cindy
pathways[['preppi']] = gbm.example$preppi

## ----moma object---------------------------------------------------------
momaObj <- moma_constructor(gbm.example$vipermat, gbm.example$rawsnp,
        gbm.example$rawcnv, gbm.example$fusions, pathways,
        gene.blacklist=gbm.example$mutSig)

## ----interactions, results = "hide", message = FALSE---------------------
momaObj$runDIGGIT(fCNV=gbm.example$fCNV, verbose = T)

momaObj$makeInteractions()

momaObj$Rank()

## ----clustering----------------------------------------------------------
momaObj$Cluster()

# pick the 3 cluster solution and save it to the moma Object
momaObj$sample.clustering <- momaObj$clustering.results[[2]]$clustering

## ----saturation, message=FALSE, results="hide"---------------------------
momaObj$saturationCalculation()

## ----checkpoints---------------------------------------------------------
cluster1.checkpoint <- momaObj$checkpoints[[1]]
print (cluster1.checkpoint[1:10])

## ----make plots, warning=FALSE-------------------------------------------
momaObj$makeSaturationPlots()

## ----visualize plots-----------------------------------------------------
library(ggplot2)
momaObj$identity.plots$bar.plots[[1]]
momaObj$identity.plots$curve.plots[[1]] + 
  ggtitle("Genomic Saturation Curve for GBM Subtype 1")
  

